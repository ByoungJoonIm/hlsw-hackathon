struct score {
	int num;
	char name[10];
	int sc1;
	int sc2;
};
typedef struct score score;

struct sclist
{
	score *psc;
	struct sclist *next;
};
typedef struct sclist sclist;
typedef sclist *pscl;

pscl put_struct(score *step) {
	//�� �� ����ü ������ �޸𸮸� �Ҵ� �޾� 
	//���Ḯ��Ʈ�� ����� �ϳ��� ���� �����.
	pscl node = (pscl)malloc(sizeof(sclist));
	node->psc = (score*)malloc(sizeof(score));
	memcpy(node->psc, step, sizeof(score));
	node->next = NULL;
	return node;
}

pscl add_list(pscl head, pscl cur) {
	//cur�� head�� �����Ѵ�. 
	pscl nextNode = head;
	if (!head) {
		head = cur;
		return head;
	}

	while (nextNode->next) {
		nextNode = nextNode->next;
	}

	nextNode->next = cur;
	return head;
}
int prt(pscl head) {
	//����Ʈ�� ��� ������ ����Ѵ�
	pscl nextNode = head;
	int sum;

	while (nextNode) {
		sum = nextNode->psc->sc1 + nextNode->psc->sc2;
		printf("\t\t%d\t%s\t%d\t%d\t%d\n",
			nextNode->psc->num, nextNode->psc->name,
			nextNode->psc->sc1, nextNode->psc->sc2, sum);
		nextNode = nextNode->next;
	}
	return 0;
}

void free_list(pscl head) {
	//�Ҵ�޾Ҵ� �޸�����
	pscl next;

	while (head) {
		next = head;
		head = head->next;
		free(next->psc);
		free(next);
	}
}

int main()
{
	FILE *fp;
	char fn[] = "input.txt";
	score sc;
	score *asc = &sc;
	pscl head = NULL;
	pscl cur;

	if (fopen_s(&fp,fn, "r")) {
		printf("can't open the file.\n");
		exit(1);
	}
	
	while (fscanf(fp, "%d\t%s\t%d\t%d\n",
		&asc->num, &asc->name, &asc->sc1, &asc->sc2) != EOF) {
		cur = put_struct(asc);
		printf("=== file read ===\t\t%d\t%s\t%d\t%d\n",
			asc->num, asc->name, asc->sc1, asc->sc2);
		head = add_list(head, cur);
	}

	fclose(fp);

	printf("\n=== read list===\n\t\tnum\tname\tsc1\tsc2\tsum\n");
	printf("======================================================\n");
	prt(head);

	free_list(head);
}