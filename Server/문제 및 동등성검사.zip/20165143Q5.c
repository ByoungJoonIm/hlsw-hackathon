int reverse(char *right,char *left){
	int count,i;

	count=0;

	while(*left){
		left++;
		count++;
	}
	left--;

	for(i=0;i<count;i++){
		*right = *left;
		right++;
		left--;
	}
	return count;
}

void ex5(){
	char str[20],rev[20];
	char *p,*pb;
	int num,i;

	do{
		
		printf("\n���ڿ� �Է�:");
		gets(str);

		p = str;

		if(!(*p)){
			printf("<EnterŰ>");
			break;
		}

	num = reverse(rev,str);
	printf("\n���� = ");
	
	pb = rev;

	for(i=0;i<num;i++){
		printf("%c",*pb);
		pb++;
	}


	}while(1);
}