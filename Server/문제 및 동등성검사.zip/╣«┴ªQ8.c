//8. ����ü ���� ����
#include <stdio.h>
#include <stdlib.h>

struct score {		
	int num;
	char name[10];
	int sc1;
	int sc2;
};

typedef struct score score;

int main(int argc, char *argv[])
{
	FILE *fp;
	score sc;
	score *asc = &sc;
	int i;

	score data[5] = { 
		{1, "������", 30, 40},
		{2, "������", 28, 37},
		{3, "��ٿ�", 32, 77},
		{4, "�����", 67, 39},
		{5, "��ҿ�", 77, 67} };

	if((fp = fopen(argv[1],"w")) == NULL) {
		printf("can't open the file.\n");
		exit(1);
	}

	fprintf(stdout, "=== file write  ===\n");
	for(i=0; i<5; i++) {
	  fprintf(fp, "%9d%9s%9d%9d\n", data[i].num, data[i].name, data[i].sc1, data[i].sc2);
	  fprintf(stdout, "%9d%9s%9d%9d\n", data[i].num, data[i].name, data[i].sc1, data[i].sc2);
	}
	fclose(fp);

	if((fp = fopen(argv[1],"r")) == NULL) {
		printf("can't open the file.\n");
		exit(1);
	}

	fprintf(stdout, "=== file read ===\n");
	fscanf(fp, "%9d%9s%9d%9d\n", &asc->num, asc->name, &asc->sc1, &asc->sc2);
	while(!feof(fp)) {
		fprintf(stdout, "%9d%9s%9d%9d\n", asc->num, asc->name, asc->sc1, asc->sc2);
		fscanf(fp, "%9d%9s%9d%9d\n", &asc->num, asc->name, &asc->sc1, &asc->sc2);
	}			
	fclose(fp);
	getchar();
	return 0;
}
