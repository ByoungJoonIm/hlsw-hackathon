void ex07_07() {
	FILE *fp;

	if (fopen_s(&fp, "score.txt", "w")) {
		puts("fopen error!");
	}

	fprintf(fp, "%d\t%s\t%.1lf\t%.1lf\n", 1, "�̽¸�", 67.2, 78.9);
	fprintf(fp, "%d\t%s\t%.1lf\t%.1lf\n", 2, "������", 77.8, 67.4);
	fprintf(fp, "%d\t%s\t%.1lf\t%.1lf\n", 3, "����ȯ", 87.4, 88.5);

	fclose(fp);
}

