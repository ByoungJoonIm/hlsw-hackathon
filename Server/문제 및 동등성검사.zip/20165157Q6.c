void ex07_06(int argc, char *argv[]) {
	FILE *fp1, *fp2;
	char txt[82];

	if (!(fp1 = fopen(argv[1], "r"))) {
		printf("%s fopen error!", argv[1]);
		return;
	}

	if (!(fp2 = fopen(argv[2], "w"))) {
		printf("%s fopen error!", argv[2]);
		return;
	}

	printf("%s�� %s�� �����մϴ�.\n", argv[1], argv[2]);

	while (fgets(txt, 81, fp1)) {
		printf("%s", txt);
		fputs(txt, fp2);
	}

	fclose(fp2);
	fclose(fp1);
}
