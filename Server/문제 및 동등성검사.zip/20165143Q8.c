void ex08(int argc,char *argv[]){
	FILE *fp;
	int i;
	char name[10];
	int num=0,sc1=0,sc2=0;
	score student[5] = {
						{1,"������",30,40},
						{2,"������",28,37},
						{3,"��ٿ�",32,77},
						{4,"�����",67,39},
						{5,"��ҿ�",77,67}
						};
	if(argc!=2) {
		printf("error!");
		return;
	}
	if(fopen_s(&fp,argv[1],"w")) {
		printf("file open error!");
		return;
	}

	for(i=0;i<5;i++){
		fprintf(fp,"%d\t%s\t%d\t%d\n",student[i].num,student[i].name,student[i].sc1,student[i].sc2);
	}
	printf("�������� �Ϸ�!\n");
	fclose(fp);

	if(fopen_s(&fp,argv[1],"r")){
		printf("������ ã�� �� �����ϴ�.");
	}
	
	fscanf(fp,"%d\t%s\t%d\t%d\n",&num,name,&sc1,&sc2);
	fprintf(stdout,"%d\t%s\t%d\t%d\n",num,name,sc1,sc2);
	while(!feof(fp)){
		fscanf(fp,"%d\t%s\t%d\t%d\n",&num,name,&sc1,&sc2);
		fprintf(stdout,"%d\t%s\t%d\t%d\n",num,name,sc1,sc2);
	}
	fclose(fp);
}


struct sclist
{
	score *psc;
	struct sclist *next;
};
typedef struct sclist sclist;
typedef sclist *pscl;


pscl put_struct(score *step){
	pscl newNode;
	newNode = (sclist*)malloc(sizeof(sclist));	//����ü��ŭ�� ũ���Ҵ�
	if(newNode==NULL){
		printf("�޸� �Ҵ� ����");
		return;
	}
	newNode->psc = (score*)malloc(sizeof(score));
	strcpy(newNode->psc->name,step->name);
	newNode->psc->num = step->num;
	newNode->psc->sc1 = step->sc1;
	newNode->psc->sc2 = step->sc2;
	newNode->next = NULL;
	return newNode;
}
pscl add_list(pscl head,pscl cur){
	pscl p=head;
	if(head==NULL){
		head = cur;
		return cur;
	}
	while(p->next!=NULL){
		p = p->next;
	}
	p->next = cur;
	return head;
}
int prt(pscl head){
	pscl p = head;
	int count=0;
	int sum ;
	
	while(p!=NULL){
		sum = p->psc->sc1+p->psc->sc2;
		printf("\n\t%d\t%s\t%d\t%d\t%d",p->psc->num,p->psc->name,p->psc->sc1,p->psc->sc2,sum);
		p = p->next;
		++count;
	}
	return count;
}

void free_list(pscl head){
	pscl nextNode = head;
	
	if(head==NULL) {
		printf("������ ��尡 �����ϴ�.");
		return;
	}
	while(head->next!=NULL){
		nextNode = head;
		head = head->next;
		free(nextNode->psc);
		nextNode->psc = NULL;
		free(nextNode);
		nextNode = NULL;
	}
	free(head->psc);
	head->psc = NULL;
	free(head);
	head = NULL;
	
}