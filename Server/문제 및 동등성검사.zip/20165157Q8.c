
#include <stdio.h>
#include <stdlib.h>

struct score {
	int num;
	char name[10];
	int sc1;
	int sc2;
};
typedef struct score score;


void main(int argc, char *argv[]) {
	score scores[5] = { { 1,"������",30,40 },
	{ 2,"������",28,37 },
	{ 3,"��ٿ�",32,77 },
	{ 4,"�����",67,39 },
	{ 5,"��ҿ�",77,67 } };
	FILE *fp;
	score rs[5];
	int i;

	if (fopen_s(&fp, "input.txt", "w")) {
		return;
	}

	for (i = 0; i<5; i++) {
		fprintf(fp, "%d\t%s\t%d\t%d\n",
			scores[i].num, scores[i].name, scores[i].sc1, scores[i].sc2);
	}

	fclose(fp);

	if (fopen_s(&fp, "input.txt", "r")) {
		return;
	}

	for (i = 0; i<5; i++) {
		fscanf(fp, "%d\t%s\t%d\t%d\n",
			&rs[i].num, &rs[i].name, &rs[i].sc1, &rs[i].sc2);
	}

	fclose(fp);

	for (i = 0; i<5; i++) {
		printf("%d\t%s\t%d\t%d\n",
			rs[i].num, rs[i].name, rs[i].sc1, rs[i].sc2);
	}
}
